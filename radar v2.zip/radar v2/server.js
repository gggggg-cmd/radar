const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const { SerialPort, ReadlineParser } = require("serialport");
const path = require("path");
const os = require("os");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = 3000;
const SERIAL_PORT = process.env.RADAR_PORT || "COM19"; // change if needed
const BAUD_RATE = 115200;

app.use(express.static(path.join(__dirname, "public")));

let latest = {
  angle: 90,
  distance: -1,
  detections: 0,
  lastDetection: null,
  sweepMin: 15,
  sweepMax: 165,
  sweepCycles: 0,
};

let detectionLog = [];
let objectTracks = [];
let lastAngle = null;
let movingForward = true;

function getLocalIP() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === "IPv4" && !net.internal) {
        return net.address;
      }
    }
  }
  return "localhost";
}

function updateObjects(angle, distance) {
  if (distance < 0) return;

  const thresholdAngle = 6;
  const thresholdDistance = 18;
  const now = Date.now();

  let matched = false;

  for (const obj of objectTracks) {
    if (
      Math.abs(obj.angle - angle) <= thresholdAngle &&
      Math.abs(obj.distance - distance) <= thresholdDistance
    ) {
      obj.samples.push({ angle, distance, t: now });
      obj.angle = Math.round(obj.samples.reduce((a, s) => a + s.angle, 0) / obj.samples.length);
      obj.distance = Math.round(obj.samples.reduce((a, s) => a + s.distance, 0) / obj.samples.length);
      obj.size = Math.max(obj.size, obj.samples.length);
      obj.lastSeen = now;
      matched = true;
      break;
    }
  }

  if (!matched) {
    objectTracks.push({
      id: `${now}-${Math.random().toString(16).slice(2, 7)}`,
      angle,
      distance,
      size: 1,
      createdAt: now,
      lastSeen: now,
      samples: [{ angle, distance, t: now }],
    });
  }

  objectTracks = objectTracks.filter(o => now - o.lastSeen < 7000);
}

function estimateSizeLabel(track) {
  if (!track) return "Unknown";
  if (track.size >= 10) return "Large";
  if (track.size >= 5) return "Medium";
  return "Small";
}

function logDetection(angle, distance) {
  const now = new Date();
  const record = {
    time: now.toLocaleTimeString(),
    angle,
    distance,
  };
  detectionLog.unshift(record);
  if (detectionLog.length > 100) detectionLog.pop();
}

function parseSerialLine(line) {
  const parts = line.trim().split(",");
  if (parts.length !== 2) return;

  const angle = parseInt(parts[0], 10);
  const distance = parseInt(parts[1], 10);

  if (Number.isNaN(angle) || Number.isNaN(distance)) return;

  if (lastAngle !== null) {
    if (lastAngle > angle) movingForward = false;
    if (lastAngle < angle) movingForward = true;

    if (!movingForward && angle <= latest.sweepMin + 1 && lastAngle > angle) {
      latest.sweepCycles++;
    }
  }
  lastAngle = angle;

  latest.angle = angle;
  latest.distance = distance;

  if (distance > 0 && distance <= 200) {
    latest.detections++;
    latest.lastDetection = { angle, distance, time: Date.now() };
    updateObjects(angle, distance);
    logDetection(angle, distance);
  }

  io.emit("radar-data", {
    ...latest,
    objects: objectTracks.map(o => ({
      id: o.id,
      angle: o.angle,
      distance: o.distance,
      size: o.size,
      sizeLabel: estimateSizeLabel(o),
      ageMs: Date.now() - o.createdAt,
    })),
    history: detectionLog.slice(0, 10),
  });
}

let port;
try {
  port = new SerialPort({
    path: SERIAL_PORT,
    baudRate: BAUD_RATE,
  });

  const parser = port.pipe(new ReadlineParser({ delimiter: "\n" }));
  parser.on("data", parseSerialLine);

  port.on("open", () => {
    console.log(`Serial connected on ${SERIAL_PORT}`);
  });

  port.on("error", (err) => {
    console.error("Serial error:", err.message);
  });
} catch (err) {
  console.error("Failed to open serial port:", err.message);
}

io.on("connection", (socket) => {
  console.log("Client connected");

  socket.emit("radar-data", {
    ...latest,
    objects: objectTracks.map(o => ({
      id: o.id,
      angle: o.angle,
      distance: o.distance,
      size: o.size,
      sizeLabel: estimateSizeLabel(o),
      ageMs: Date.now() - o.createdAt,
    })),
    history: detectionLog.slice(0, 10),
  });

  socket.on("manual-config", (cfg) => {
    io.emit("manual-config", cfg);
  });

  socket.on("request-report", () => {
    const report = {
      totalDetections: latest.detections,
      sweepCycles: latest.sweepCycles,
      activeObjects: objectTracks.map(o => ({
        angle: o.angle,
        distance: o.distance,
        sizeLabel: estimateSizeLabel(o),
      })),
      recentDetections: detectionLog.slice(0, 20),
      generatedAt: new Date().toLocaleString(),
    };
    socket.emit("scan-report", report);
  });
});

server.listen(PORT, "0.0.0.0", () => {
  const ip = getLocalIP();
  console.log(`Radar server running:`);
  console.log(`Local:   http://localhost:${PORT}`);
  console.log(`Phone:   http://${ip}:${PORT}`);
});