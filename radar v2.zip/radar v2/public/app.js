const socket = io();

const canvas = document.getElementById("radarCanvas");
const ctx = canvas.getContext("2d");

const angleValue = document.getElementById("angleValue");
const distanceValue = document.getElementById("distanceValue");
const detectionsValue = document.getElementById("detectionsValue");
const sweepsValue = document.getElementById("sweepsValue");
const historyList = document.getElementById("historyList");
const reportOutput = document.getElementById("reportOutput");
const connectionPill = document.getElementById("connectionPill");

const startAngle = document.getElementById("startAngle");
const endAngle = document.getElementById("endAngle");
const scanRepeats = document.getElementById("scanRepeats");
const startAngleLabel = document.getElementById("startAngleLabel");
const endAngleLabel = document.getElementById("endAngleLabel");
const applyConfigBtn = document.getElementById("applyConfigBtn");
const reportBtn = document.getElementById("reportBtn");
const audioBtn = document.getElementById("audioBtn");

let radarState = {
  angle: 90,
  distance: -1,
  detections: 0,
  sweepCycles: 0,
  objects: [],
  history: []
};

let trail = [];
let audioEnabled = true;
let audioContext = null;
let lastBeepTime = 0;
let lastDataTs = 0;

function initAudio() {
  if (!audioContext) {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
  }
}

document.body.addEventListener("click", initAudio, { once: true });

function beep(distance) {
  if (!audioEnabled || !audioContext || distance <= 0) return;

  const now = Date.now();
  const gap = Math.max(70, Math.min(520, distance * 4));
  if (now - lastBeepTime < gap) return;
  lastBeepTime = now;

  const osc = audioContext.createOscillator();
  const gain = audioContext.createGain();

  osc.type = "triangle";
  osc.frequency.value = Math.max(260, 1250 - distance * 4);
  gain.gain.value = 0.035;

  osc.connect(gain);
  gain.connect(audioContext.destination);

  osc.start();
  osc.stop(audioContext.currentTime + 0.07);
}

function degToRad(d) {
  return (d * Math.PI) / 180;
}

function polarToCanvas(angle, distance, cx, by, radiusMax) {
  const rr = (distance / 200) * radiusMax;
  const rad = degToRad(180 - angle);
  return {
    x: cx + rr * Math.cos(rad),
    y: by - rr * Math.sin(rad)
  };
}

function drawBackground(w, h) {
  ctx.clearRect(0, 0, w, h);

  const grad = ctx.createRadialGradient(w / 2, h - 40, 20, w / 2, h - 40, h);
  grad.addColorStop(0, "rgba(70,255,170,0.08)");
  grad.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  for (let i = 0; i < 50; i++) {
    const x = (i * 173) % w;
    const y = (i * 97) % h;
    ctx.fillStyle = "rgba(255,255,255,0.025)";
    ctx.fillRect(x, y, 1.5, 1.5);
  }
}

function drawRadar() {
  const w = canvas.width;
  const h = canvas.height;

  drawBackground(w, h);

  const cx = w / 2;
  const by = h - 32;
  const maxR = Math.min(w * 0.42, h * 0.82);

  // outer frame glow
  ctx.strokeStyle = "rgba(120,180,255,0.14)";
  ctx.lineWidth = 2;
  ctx.strokeRect(1, 1, w - 2, h - 2);

  // arcs
  for (let i = 1; i <= 4; i++) {
    ctx.beginPath();
    ctx.arc(cx, by, (maxR / 4) * i, Math.PI, Math.PI * 2);
    ctx.strokeStyle = i === 4 ? "rgba(108,255,180,0.5)" : "rgba(108,255,180,0.22)";
    ctx.lineWidth = i === 4 ? 3 : 2;
    ctx.stroke();
  }

  // angle guides
  for (let a = 15; a <= 165; a += 15) {
    const rad = degToRad(180 - a);
    const x = cx + maxR * Math.cos(rad);
    const y = by - maxR * Math.sin(rad);
    ctx.beginPath();
    ctx.moveTo(cx, by);
    ctx.lineTo(x, y);
    ctx.strokeStyle = "rgba(108,255,180,0.11)";
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }

  // labels
  ctx.fillStyle = "rgba(228,255,240,0.95)";
  ctx.font = "bold 26px Arial";
  ctx.fillText("50cm", cx + maxR / 4 - 20, by - 10);
  ctx.fillText("100cm", cx + maxR / 2 - 30, by - 10);
  ctx.fillText("150cm", cx + (3 * maxR) / 4 - 30, by - 10);
  ctx.fillText("200cm", cx + maxR - 30, by - 10);

  // trail
  trail.forEach((p, i) => {
    const alpha = (i + 1) / trail.length;
    const pos = polarToCanvas(p.angle, p.distance, cx, by, maxR);
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 3 + alpha * 4, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(92,164,255,${alpha * 0.35})`;
    ctx.fill();
  });

  // objects
  radarState.objects.forEach((obj) => {
    const pos = polarToCanvas(obj.angle, obj.distance, cx, by, maxR);

    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 12, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,107,127,0.18)";
    ctx.fill();

    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 7, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,107,127,0.95)";
    ctx.fill();

    ctx.strokeStyle = "rgba(255,255,255,0.75)";
    ctx.lineWidth = 2;
    ctx.strokeRect(pos.x - 11, pos.y - 11, 22, 22);

    ctx.fillStyle = "rgba(255,255,255,0.95)";
    ctx.font = "bold 18px Arial";
    ctx.fillText(obj.sizeLabel || "OBJ", pos.x + 14, pos.y - 12);
  });

  // sweep beam
  const a = radarState.angle;
  const rad = degToRad(180 - a);

  for (let spread = -5; spread <= 5; spread += 1) {
    const sr = degToRad(180 - (a + spread));
    const x = cx + maxR * Math.cos(sr);
    const y = by - maxR * Math.sin(sr);

    ctx.beginPath();
    ctx.moveTo(cx, by);
    ctx.lineTo(x, y);
    ctx.strokeStyle = `rgba(108,255,180,${spread === 0 ? 0.95 : 0.07})`;
    ctx.lineWidth = spread === 0 ? 5 : 2;
    ctx.stroke();
  }

  // current target
  if (radarState.distance > 0 && radarState.distance <= 200) {
    const pos = polarToCanvas(radarState.angle, radarState.distance, cx, by, maxR);

    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 18, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(255,107,127,0.85)";
    ctx.lineWidth = 3;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 7, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,255,255,0.95)";
    ctx.fill();
  }
}

function updateHistory(history) {
  historyList.innerHTML = "";

  if (!history || history.length === 0) {
    historyList.innerHTML = `<div class="history-item">No detections yet.</div>`;
    return;
  }

  history.forEach((item) => {
    const div = document.createElement("div");
    div.className = "history-item";
    div.textContent = `${item.time} — ${item.distance} cm at ${item.angle}°`;
    historyList.appendChild(div);
  });
}

socket.on("connect", () => {
  connectionPill.textContent = "CONNECTED";
});

socket.on("disconnect", () => {
  connectionPill.textContent = "DISCONNECTED";
});

socket.on("radar-data", (data) => {
  radarState = data;
  lastDataTs = Date.now();

  angleValue.textContent = `${data.angle}°`;
  distanceValue.textContent = data.distance > 0 ? `${data.distance} cm` : "No target";
  detectionsValue.textContent = data.detections;
  sweepsValue.textContent = data.sweepCycles;

  if (data.distance > 0 && data.distance <= 200) {
    trail.push({ angle: data.angle, distance: data.distance });
    if (trail.length > 35) trail.shift();
    beep(data.distance);
  }

  updateHistory(data.history || []);
  drawRadar();
});

socket.on("scan-report", (report) => {
  reportOutput.textContent = JSON.stringify(report, null, 2);
});

startAngle.addEventListener("input", () => {
  startAngleLabel.textContent = `${startAngle.value}°`;
});

endAngle.addEventListener("input", () => {
  endAngleLabel.textContent = `${endAngle.value}°`;
});

applyConfigBtn.addEventListener("click", () => {
  const cfg = {
    startAngle: Number(startAngle.value),
    endAngle: Number(endAngle.value),
    scanRepeats: Number(scanRepeats.value)
  };
  reportOutput.textContent =
    `UI Config Applied\n\n${JSON.stringify(cfg, null, 2)}\n\nThis currently updates UI preferences only.`;
});

reportBtn.addEventListener("click", () => {
  socket.emit("request-report");
});

audioBtn.addEventListener("click", async () => {
  initAudio();
  if (audioContext && audioContext.state === "suspended") {
    await audioContext.resume();
  }
  audioEnabled = !audioEnabled;
  audioBtn.textContent = audioEnabled ? "Audio ON" : "Audio OFF";
});

function monitorLiveData() {
  if (Date.now() - lastDataTs > 2500) {
    connectionPill.textContent = "WAITING DATA";
  }
  requestAnimationFrame(monitorLiveData);
}

function animate() {
  drawRadar();
  requestAnimationFrame(animate);
}

drawRadar();
animate();
monitorLiveData();